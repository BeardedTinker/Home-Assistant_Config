const a=a=>`https://brands.home-assistant.io/${a.useFallback?"_/":""}${a.domain}/${a.darkOptimized?"dark_":""}${a.type}.png`;export{a as b};
